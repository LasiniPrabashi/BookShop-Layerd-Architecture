package lk.ijse.BookShop.bo;

public interface SuperBO {
}
