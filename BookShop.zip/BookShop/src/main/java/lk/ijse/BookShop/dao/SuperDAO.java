package lk.ijse.BookShop.dao;

public interface SuperDAO {
}
